#!/usr/bin/env python
# coding: utf-8

# # Process Data Table
# 
# This notebook takes patient data and processes it into the format suggested by the flexsurv R package for fitting a multi-state survival model.
# 
# Start by Pulling in relevant libraries.
# 

#### load packages
import numpy as np
import scipy as sp
import scipy.stats as st
import scipy.optimize as op
from scipy import integrate
import matplotlib.pyplot as plt
import pandas as pd
from datetime import datetime, date, timedelta
from tqdm import tqdm
import os
from src.configuration.setup_config import SetupConfig

NUMBER_SECONDS_PER_DAY = 60 * 60 * 24
NUMBER_DAYS_PER_YEAR = 365
INPUT_FILE_COLUMNS = ["NHSNumber", "HospitalAdmissionTime", "StartTimeCriticalCare", "DischargeTimeCriticalCare", "HospitalDischargeTime",  "DateOfDeath", "DateOfBirth"]
TRANS_COLUMNS = ["NHSNumber", "Time", "Age", "ICU_cov", "State", "TimeInState", "From", "To", "Observed", "TransitionNumber"]

# Matrix of allowed transitions
Q = [
    [0, 1, 0, 1, 1],
    [0, 0, 1, 0, 1],
    [0, 0, 0, 1, 0],
    [0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0]
]

def run(setup_file_path):
    #### Load configuration file
    #### Note that configuration changes should take place in the "config.ini" configuration file rather than here
    setup_data = SetupConfig(setup_file_path)

    age_bounds = setup_data.age_bounds()

    #print(age_bounds)
    file_date = setup_data.extract_date_filename() # update to extract date
    last_data_update_datetime = setup_data.last_data_update_datetime() # update to last day on which data is updated

    # Load data
    df = pd.read_csv(setup_data.base_file_path() + setup_data.ward_identifier() + '_' + file_date+'.csv', header = None, names=INPUT_FILE_COLUMNS)

    # Convert string dates to datetimes
    # not sure that this does anything to the data
    df = convertStringDatestoDateTimes(df)

    # replaced by function
    df = extractAdmissionAndDischarge(df)

    # Create a data frame - each row corresponds to a transition made by an individual along with time of transition
    # since admission and covariate values.

    Qbase, new_df = calculateTransitions(Q, df, last_data_update_datetime,age_bounds)

    # Save length of stay data frame
    create_temp_folder_if_not_exists(setup_data.base_file_path())
    new_df.to_csv(setup_data.base_file_path() + 'temp\\patient_transitions_' + file_date + '.csv')

    Tmax, censusOutput = createCensus(Qbase, df, setup_data, new_df,age_bounds)

    # Save census
    pd.DataFrame((np.asarray(censusOutput))).to_csv(setup_data.base_file_path() + 'temp\\hospital_census_' + file_date + '.csv', index=False)

    generateAdmissionsFile(Tmax, censusOutput, setup_data)


def days(dateStop, dateStart):
    # Returns days since date_start
    return int((np.floor((dateStop - dateStart).total_seconds() / (NUMBER_SECONDS_PER_DAY))))


def convertStringDatestoDateTimes(df):
    # Convert string dates to datetimes

    for i in range(0, len(df)):
        startTimeCriticalCare = df.StartTimeCriticalCare.values[i]
        dischargeTimeCriticalCare = df.DischargeTimeCriticalCare.values[i]
        dateOfDeath = df.DateOfDeath.values[i]
        hospitalDischargeTime = df.HospitalDischargeTime.values[i]

        if pd.isna(df.HospitalAdmissionTime.values[i]):
            raise ValueError("Missing value for HospitalAdmissionTime")
        if pd.isna(df.DateOfBirth.values[i]):
            raise ValueError("Missing value for DateOfBirth")

        if not pd.isna(startTimeCriticalCare):
            df.StartTimeCriticalCare.iloc[i] = datetime.fromisoformat(startTimeCriticalCare)
        if not pd.isna(dischargeTimeCriticalCare):
            df.DischargeTimeCriticalCare.iloc[i] = datetime.fromisoformat(dischargeTimeCriticalCare)
        if not pd.isna(dateOfDeath):
            df.DateOfDeath.iloc[i] = datetime.fromisoformat(dateOfDeath)
        if not pd.isna(hospitalDischargeTime):
            df.HospitalDischargeTime.iloc[i] = datetime.fromisoformat(hospitalDischargeTime)

        df.HospitalAdmissionTime.iloc[i] = datetime.fromisoformat(df.HospitalAdmissionTime.values[i])
        df.DateOfBirth.iloc[i] = datetime.fromisoformat(df.DateOfBirth.values[i])
    return df


def extractAdmissionAndDischarge(df):
     # For each NHS Number, extract the patient's first admission and final discharge
    # (can be omitted if interested in tracking multiple admissions)
    # It is probably best to keep this in, as in the (MFT) data most individuals are quickly readmitted...
    # ...suggesting discharge decision was incorrect rather than a genuine state transition
    ids = df['NHSNumber'].unique()

    for i in tqdm(ids):
        NHS_df = df.loc[df['NHSNumber'] == i]  # find
        firstAdmission = NHS_df['HospitalAdmissionTime'].min()

        # if ICU admission exists, remove all duplicates without ICU times
        if NHS_df['StartTimeCriticalCare'].notnull().values.any():
            removal = NHS_df.index[NHS_df['StartTimeCriticalCare'].isnull()].tolist()
            df = df.drop(removal).reset_index(drop=True)
        NHS_df = df.loc[df['NHSNumber'] == i]  # find
        firstICUadmission = NHS_df['StartTimeCriticalCare'].min()

        # find last discharge time
        if NHS_df['HospitalDischargeTime'].isnull().values.any():
            lastDischarge = float('nan')
        else:
            lastDischarge = NHS_df['HospitalDischargeTime'].max()  # otherwie set as max discharge time
        removal1 = NHS_df.index[NHS_df['HospitalAdmissionTime'] > firstAdmission].tolist()

        # find last ICU discharge time
        if NHS_df['DischargeTimeCriticalCare'].isnull().values.any():
            lastICUdischarge = float('nan')  # last ICU discharge NaN
        else:
            lastICUdischarge = NHS_df['DischargeTimeCriticalCare'].max()  # last ICU discharge exists
        removal2 = NHS_df.index[NHS_df['StartTimeCriticalCare'] > firstICUadmission].tolist()

        if not pd.isna(NHS_df['DateOfDeath'].values).all():
            removal3 = NHS_df.index[NHS_df['DateOfDeath'].isnull()].tolist()
        else:
            removal3 = []

        # remove extra hospital admissions and apend last discharge to first admission
        df = df.drop(sorted(np.unique(removal1 + removal2 + removal3))).reset_index(drop=True)
        df.loc[df['NHSNumber'] == i, 'HospitalDischargeTime'] = lastDischarge
        # append last ICU discharge to first ICU admission
        df.loc[df['NHSNumber'] == i, 'DischargeTimeCriticalCare'] = lastICUdischarge
        NHS_df = df.loc[df['NHSNumber'] == i]  # find

        # check death date, if this is within 5 days of discharge, treat this as a death in hospital and amend
        # discharge time
        if NHS_df['DateOfDeath'].notnull().values.any():
            deathDate = NHS_df['DateOfDeath'].min()
            if (deathDate > lastDischarge) & (deathDate < lastDischarge + timedelta(5)):
                df.loc[df['NHSNumber'] == i, 'HospitalDischargeTime'] = deathDate

    df = df.drop_duplicates()
    return df

def generateAdmissionsFile(Tmax, output, setup_data):
    age_bounds = setup_data.age_bounds()
    NUMBER_OF_AGE_GROUPS = len(age_bounds)-1
    # Generate input file for Fit_Admissions_Growth.R
    # number of days over which to estimate the growth rate trend. Try between 28 and 100.
    growth_len = setup_data.growth_trend_length()
    df = np.zeros((growth_len, NUMBER_OF_AGE_GROUPS + 2))
    df[:, 0] = range(1, growth_len + 1)
    for index in range(0, NUMBER_OF_AGE_GROUPS):
        df[:, index + 1] = output[(Tmax - growth_len + 1):(Tmax + 1), ((index + 1) * 6 - 1)]
    df[:, NUMBER_OF_AGE_GROUPS + 1] = np.sum(df[:, 1:NUMBER_OF_AGE_GROUPS + 1], axis=1)
    df = pd.DataFrame((np.asarray(df)))
    #df.columns = ["dates", "counts_1", "counts_2", "counts_3", "counts_4", "counts_5"]
    df.to_csv(setup_data.base_file_path() + 'temp\\admissions_' + setup_data.extract_date_filename() + '.csv', index=False)
    return df


def createCensus(Qbase, df, setup_data, new_df,age_bounds):
    NUMBER_OF_AGE_GROUPS = len(age_bounds)-1
    # Define time series for census
    # num_trans = np.max(Qbase)
    numStates = len(Qbase)
    Tmax = int(np.floor((setup_data.last_admission_datetime() - setup_data.output_start_datetime()).total_seconds() / NUMBER_SECONDS_PER_DAY))
    # newcensusb = np.zeros((Tmax, numStates + 1))

    # Create a 'census' of the hospital
    outputCensus = np.zeros((Tmax + 1, NUMBER_OF_AGE_GROUPS * (numStates + 1)))
    for j_index in tqdm(range(0, NUMBER_OF_AGE_GROUPS)):
        newCensus = np.zeros((Tmax + 1, numStates + 1))

        idsCovariates = new_df.loc[new_df['Age'] == j_index]
        idsCovariates = idsCovariates['NHSNumber'].unique()
        for i in tqdm(idsCovariates):
            NHS_df = df.loc[df['NHSNumber'] == i]
            Hosp_admissionTime = NHS_df.HospitalAdmissionTime.values[0]
            Hosp_dischargeTime = NHS_df.HospitalDischargeTime.values[-1]
            ICU_admit = NHS_df.StartTimeCriticalCare.values
            ICU_discharge = NHS_df.DischargeTimeCriticalCare.values[-1]
            NHS_discharge = NHS_df.HospitalDischargeTime.values[-1]
            dateOfDeath = NHS_df.DateOfDeath.values[-1]

            # Logical indicator for death in hospital ward

            diedInHospital = False
            if not pd.isna(dateOfDeath):
                if dateOfDeath <= NHS_discharge:
                    diedInHospital = True

            # Gives one more than observed in ward at end
            Hosp_admissionDay = days(Hosp_admissionTime, setup_data.output_start_datetime())
            newCensus[Hosp_admissionDay, 5] += 1

            # if not pd.isna(NHS_discharge):
            #     Hosp_discharge_day = days(NHS_discharge, setup_data.output_start_datetime())

            if np.any(~pd.isna(ICU_admit)):  # Went to ICU
                ICU_starts = ICU_admit[~pd.isna(ICU_admit)]
                ICU_start = days(ICU_starts[0], setup_data.output_start_datetime())
                newCensus[Hosp_admissionDay:ICU_start, 0] += 1
            elif (not diedInHospital) and (not pd.isna(NHS_discharge)):  # Discharged not died
                Hosp_dischargeDay = days(Hosp_dischargeTime, setup_data.output_start_datetime())
                newCensus[Hosp_admissionDay:Hosp_dischargeDay, 0] += 1
            elif diedInHospital:  # Died
                Hosp_deathDay = days(dateOfDeath, setup_data.output_start_datetime())
                newCensus[Hosp_admissionDay:Hosp_deathDay, 0] += 1
            else:  # Nothing Happened
                newCensus[Hosp_admissionDay:, 0] += 1

            criticalCare = NHS_df[['StartTimeCriticalCare', 'DischargeTimeCriticalCare']].values
            criticalCareEntries = criticalCare[:, 0]
            criticalCareLeaves = criticalCare[:, 1]
            jj = ~pd.isna(criticalCareEntries)
            criticalCareEntries = criticalCareEntries[jj]
            criticalCareLeaves = criticalCareLeaves[jj]
            for k in range(0, len(criticalCareEntries)):
                ICU_admissionDay = days(criticalCareEntries[k], setup_data.output_start_datetime())
                if not pd.isna(criticalCareLeaves[k]):
                    ICU_dischargeDay = days(criticalCareLeaves[k], setup_data.output_start_datetime())
                    newCensus[ICU_admissionDay:ICU_dischargeDay, 1] += 1
                else:
                    newCensus[ICU_admissionDay:, 1] += 1

                if k > 0:  # TO ADD TO STEPDOWN CENSUS
                    ICU_returnDay = days(criticalCareEntries[k], setup_data.output_start_datetime())
                    ICU_lastDay = days(criticalCareLeaves[k - 1], setup_data.output_start_datetime())
                    newCensus[ICU_lastDay:ICU_returnDay, 2] += 1

            if not pd.isna(ICU_discharge):  # If not died in ICU, final stepdown
                ICU_dischargeDay = days(ICU_discharge, setup_data.output_start_datetime())
                if not pd.isna(NHS_discharge):
                    Hosp_dischargeDay = days(NHS_discharge, setup_data.output_start_datetime())
                    newCensus[ICU_dischargeDay:Hosp_dischargeDay, 2] += 1

                else:
                    newCensus[ICU_dischargeDay:, 2] += 1

            if not pd.isna(NHS_discharge):
                if diedInHospital:
                    deathDay = days(NHS_discharge, setup_data.output_start_datetime())
                    newCensus[deathDay:, 4] += 1
                else:
                    dischargeDay = days(NHS_discharge, setup_data.output_start_datetime())
                    newCensus[dischargeDay:, 3] += 1
        outputCensus[:, j_index * (numStates + 1):((j_index + 1) * (numStates + 1))] = newCensus
    return Tmax, outputCensus


def calculateTransitions(Q, df, last_data_update_datetime,age_bounds):
    new_df = pd.DataFrame()
    ids = df['NHSNumber'].unique()
    for l, i in tqdm(enumerate(ids)):

        # Extracting relevant times for an individual
        NHS_df = df.loc[df['NHSNumber'] == i]
        if len(NHS_df) > 1:
           NHS_df = NHS_df.dropna(axis=0, subset=["StartTimeCriticalCare"])
        hospitalStay = NHS_df.HospitalAdmissionTime.values[0]
        adt = NHS_df.HospitalAdmissionTime.values[0]
        ICU_admit = NHS_df.StartTimeCriticalCare.values
        ICU_discharge = NHS_df.DischargeTimeCriticalCare.values[-1]
        NHS_discharge = NHS_df.HospitalDischargeTime.values[-1]
        dateOfBirth = NHS_df.DateOfBirth.values[0]
        NHS_death = NHS_df.DateOfDeath.values[-1]
        states = np.ones(1)

        if ICU_admit[0] == adt:  # addition to amend the zero durations, as the model doesn't deal with zeros
            hospitalStay = ICU_admit[0] - timedelta(0.1)
            adt = ICU_admit[0] - timedelta(0.1)

        # Logical indicator for death in hospital ward and not an ICU
        if pd.isna(ICU_admit[0]):
            if not pd.isna(NHS_discharge):
                hospitalDeath = ((not pd.isna(NHS_death)) and NHS_death <= NHS_discharge)
            else:
                hospitalDeath = (not pd.isna(NHS_death))

        elif not pd.isna(ICU_discharge):
            if not pd.isna(NHS_discharge):
                hospitalDeath = ((not pd.isna(NHS_death)) and NHS_death <= NHS_discharge
                              and ICU_discharge < NHS_discharge) or (ICU_discharge < NHS_discharge)
            else:
                hospitalDeath = (not pd.isna(NHS_death))
        else:
            hospitalDeath = False
        # Logical indicator for death in an ICU
        if not pd.isna(ICU_discharge) and not pd.isna(NHS_death):
            ICU_death = (not pd.isna(ICU_admit[0]) and not hospitalDeath and not (
                    pd.isna(NHS_death) and NHS_death <= ICU_discharge))
        else:
            ICU_death = False

        if hospitalDeath == False and ICU_death == False and ICU_discharge == NHS_discharge:
            NHS_discharge = ICU_discharge + timedelta(0.1)

        # Create new row for each transition, with corresponding state
        if not pd.isna(ICU_admit[0]):  # Do you have an ICU stay?

            criticalCare = NHS_df[['StartTimeCriticalCare', 'DischargeTimeCriticalCare']].values
            criticalCare = criticalCare[~pd.isna(criticalCare)]

            n_rows = np.size(criticalCare)  # Each element should have its own row
            criticalCare = np.resize(criticalCare, (n_rows, 1))
            criticalCareStates = np.zeros(len(criticalCare))

            for k in range(0, n_rows):  # States alternate between 2 and 3 if multiple ICU visits exist
                if k % 2 == 0:
                    criticalCareStates[k] = 2
                else:
                    criticalCareStates[k] = 3

            # Has a person died in the ICU?
            if not pd.isna(NHS_death):
                if pd.isna(ICU_discharge):
                    criticalCareStates[-1] = 5
                elif NHS_death <= ICU_discharge:
                    criticalCareStates[-1] = 5

            # Deal with case where individuals are admitted straight to ICU
            if ICU_admit[0] == adt:
                hospitalStay = criticalCare  # - timedelta(0.1)
                states = criticalCareStates.T
            else:
                hospitalStay = np.append(hospitalStay, criticalCare)  # Append hospital admission and ICU times
                states = np.append(states, criticalCareStates)

                # End state, 5 corresponds to death, 4 to discharge
        if hospitalDeath and (not pd.isna(NHS_death)):
            states = np.append(states, 5)
        elif (not ((not pd.isna(NHS_death)) and (
                pd.isna(ICU_discharge) or NHS_death <= ICU_discharge or pd.isna(ICU_admit[0])))
              and (not pd.isna(NHS_discharge)) or (NHS_death > NHS_discharge)):
            states = np.append(states, 4)

        
        # Check this is a discharge (not transfer/death)
        if (not pd.isna(NHS_discharge)) and (NHS_discharge != ICU_discharge):
            hospitalStay = np.append(hospitalStay, NHS_discharge)

        # Reshape into desired format for data frame
        if isinstance(hospitalStay, date):
            hospitalStay = np.array([hospitalStay])
        else:
            hospitalStay = np.resize(hospitalStay, (len(hospitalStay), 1))

        # Creates a covariate that is set to 1 after a patient is discharged from ICU
        numberOfEvents = len(hospitalStay)
        ICU_covariate = np.ones(numberOfEvents)
        if ICU_admit[0] == adt:
            ICU_covariate[0] = 0
        else:
            ICU_covariate[0:np.minimum(numberOfEvents, 2)] = 0

        # Categorising individuals into age groups
        # age = np.floor((adt - dateOfBirth).days / NUMBER_DAYS_PER_YEAR)
        # if age < 26 and age > 0:
        #     age = 0
        # elif age < 51 and age > 25:
        #     age = 1
        # elif age < 76 and age > 50:
        #     age = 2
        # elif age > 75:
        #     age = 3
            
        age_temp = (adt-dateOfBirth).days/NUMBER_DAYS_PER_YEAR
        age = "NA"
        for a in range(0,len(age_bounds)-1):
            if (age_temp < age_bounds[a+1] and age_temp >= age_bounds[a]):
                age = a
   
        # if age >= 0 and age < len(age_bounds)-1:   
        #     age = age
        # else:
        #     age = -1

        ages = np.repeat(age, numberOfEvents)
        adt = np.repeat(adt, numberOfEvents)

        timepull = (last_data_update_datetime - hospitalStay.flatten()[-1]).total_seconds() / (NUMBER_SECONDS_PER_DAY)
        # Create the full data frame for an individual
        # Catches 1errors for individuals discharged directly from ICU (assumed to be transfers) # look at removing this
        try:
            for k in range(0, numberOfEvents):
                hospitalStay[k] = ((hospitalStay[k] - adt)[0].total_seconds()) / (NUMBER_SECONDS_PER_DAY)
            if numberOfEvents == 1:
                hospitalStay = np.append(hospitalStay, [ages[0], ICU_covariate[0], states[0]])
                hospitalStay = pd.DataFrame(hospitalStay).T
            else:
                hospitalStay = np.concatenate([hospitalStay, np.atleast_2d(ages).T, np.atleast_2d(ICU_covariate).T,
                                               np.atleast_2d(states).T], axis=1)
                hospitalStay = pd.DataFrame(hospitalStay)

            # Creates number of censoring rows based on possible transitions from each state
            k = 0
            ndups = []
            Qbase = Q.copy()
            for c in range(0, len(Q)):
                ndups.append(0)
                for j in range(0, len(Q[c])):
                    if Q[c][j] == 1:
                        k += 1
                        Qbase[c][j] = k
                        ndups[c] += 1

            duplicatedDFvalues = []

            for b in range(0, len(hospitalStay)):
                row = hospitalStay.iloc[b, :].values
                ii = int(hospitalStay.iloc[b, 3])
                nreps = ndups[ii - 1]
                if b < (len(hospitalStay) - 1):  # Not an end
                    jj = int(hospitalStay.iloc[b + 1, 3])
                    for qi, qval in enumerate(Qbase[ii - 1]):
                        if qval > 0:
                            if hospitalStay.iloc[b + 1, 0] - hospitalStay.iloc[b, 0] <= 0:
                                # All durations should be positive non-zero values, since transitions should not be
                                # instantanous
                                print("NHS Number =" + str(
                                    i) + "Negative or zero length duration encountered, please check rounding in data")
                            if qi == (jj - 1):
                                newrow = np.append(row, [hospitalStay.iloc[b + 1, 0] -
                                                         hospitalStay.iloc[b, 0], ii, jj, 1,
                                                         qval])  # Observed transition
                            else:
                                newrow = np.append(row, [hospitalStay.iloc[b + 1, 0] -
                                                         hospitalStay.iloc[b, 0], ii, qi + 1, 0,
                                                         qval])  # Possible transitions (not observed)
                            duplicatedDFvalues.append(newrow)
                else:
                    for qi, qval in enumerate(Qbase[ii - 1]):
                        if qval > 0:
                            newrow = np.append(row, [timepull, ii, qi + 1, 0, qval])  # Possible transitions (censored)
                            duplicatedDFvalues.append(newrow)

            hospitalStayForFS = pd.DataFrame(duplicatedDFvalues)
            NHS_nos = pd.DataFrame(np.repeat(i, len(hospitalStayForFS)))
            dfIndividual = pd.concat([NHS_nos, hospitalStayForFS], axis=1)
            new_df = new_df.append(dfIndividual)
        except:
            print('Caught append error at step ' + str(l) + ' NHS Number =' + str(i))
            continue
    new_df.columns = TRANS_COLUMNS
    new_df = new_df[new_df["Age"] != "NA"]
    return Qbase, new_df

def create_temp_folder_if_not_exists(path_to):
    temp_dir_path = path_to + "\\temp"
    if not os.path.exists(temp_dir_path):
        os.mkdir(temp_dir_path)

if __name__ == "__main__":
    run("src\\configuration\\setup_configuration_file.txt")
