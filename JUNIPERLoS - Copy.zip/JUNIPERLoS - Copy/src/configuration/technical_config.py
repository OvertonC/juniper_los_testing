from src.configuration.config import Config

class TechnicalConfig():
    _identifier = "TECHNICAL_CONFIG"
    _number_of_values = 6
    _config = None

    def __init__(self, config_file_path):
        self._config = Config(config_file_path)
        self.verify_value_count()
    
    def verify_value_count(self):
        found_values = self._config.count_values_in_section(self._identifier)
        if found_values != self._number_of_values:
            raise IOError("It looks like there is a problem with the {} file. Expected to find {} lines of text in this file but actually found {}".format(self._config.config_file_path, self._number_of_values, found_values)) 
    
    def nboot(self):
        return self._config.get_int(self._identifier, "NBOOT")
    
    def npat(self):
        return self._config.get_int(self._identifier, "NPAT")
    
    def draw_num(self):
        return self._config.get_int(self._identifier, "DRAW_NUM")

    def tune_num(self):
        return self._config.get_int(self._identifier, "TUNE_NUM")

    def chain_num(self):
        return self._config.get_int(self._identifier, "CHAIN_NUM")
    
    def core_num(self):
        return self._config.get_int(self._identifier, "CORE_NUM")
