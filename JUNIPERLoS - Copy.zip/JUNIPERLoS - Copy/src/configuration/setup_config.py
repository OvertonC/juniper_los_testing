from src.configuration.config import Config

class SetupConfig():
    _identifier = "SETUP_CONFIG"
    _number_of_values = 18
    _config = None

    def __init__(self, config_file_path):
        self._config = Config(config_file_path)
        self.verify_value_count()
        
    def verify_value_count(self):
        found_values = self._config.count_values_in_section(self._identifier)
        if found_values != self._number_of_values:
            raise IOError("It looks like there is a problem with the {} file. Expected to find {} lines of text in this file but actually found {}".format(self._config.config_file_path, self._number_of_values, found_values)) 

    def base_file_path(self):
        file_path = self._config.get_string(self._identifier, "BASE_FILE_PATH")
        return self.append_trailing_slash_if_not_exists(file_path)

    def ward_identifier(self):
        return self._config.get_string(self._identifier, "WARD_IDENTIFIER")
    
    def extract_date_filename(self):
        return self._config.get_string(self._identifier, "EXTRACT_DATE_FILENAME")
    
    def output_start_datetime(self):
        return self._config.get_datetime(self._identifier, "OUTPUT_START_DATETIME")

    def last_admission_datetime(self):
        return self._config.get_datetime(self._identifier, "LAST_ADMISSION_DATETIME")

    def last_data_update_datetime(self):
        return self._config.get_datetime(self._identifier, "LAST_DATA_UPDATE_DATETIME")

    def growth_trend_length(self):
        return self._config.get_int(self._identifier, "GROWTH_TREND_LENGTH_DAYS")

    def forecast_start_date(self):
        return self._config.get_date(self._identifier, "FORECAST_START_DATE")

    def approx_growth(self):
        return self._config.get_bool(self._identifier, "APPROX_GROWTH_BOOL")

    def under_twenty_six_to_ICU(self):
        return self._config.get_bool(self._identifier, "0_25_TO_ICU_BOOL")

    def twenty_six_to_fifty_to_ICU(self):
        return self._config.get_bool(self._identifier, "26_50_TO_ICU_BOOL")

    def fifty_one_to_seventy_five_to_ICU(self):
        return self._config.get_bool(self._identifier, "51_75_TO_ICU_BOOL")

    def seventy_six_and_over_to_ICU(self):
        return self._config.get_bool(self._identifier, "76_100_TO_ICU_BOOL")

    def use_saved_fitting(self):
        return self._config.get_bool(self._identifier, "USE_SAVED_FITTING_BOOL")

    def use_single_distribution(self):
        return self._config.get_bool(self._identifier, "USE_SINGLE_DISTRIBUTION_BOOL")

    def generate_length_of_stay_estimates(self):
        return self._config.get_bool(self._identifier, "GENERATE_LENGTH_OF_STAY_ESTIMATES_BOOL")
    
    def age_bounds(self):
        return self._config.get_bounds(self._identifier, "AGE_BOUNDS")

    def use_predefined_admissions(self):
        return self._config.get_bool(self._identifier, "USE_PREDEFINED_ADMISSIONS_BOOL")
    
    def append_trailing_slash_if_not_exists(self, file_path):
        length = len(file_path)
        if(file_path[length-1] != '\\'):
            file_path += '\\'
        return file_path