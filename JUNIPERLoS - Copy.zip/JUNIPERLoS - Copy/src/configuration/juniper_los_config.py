from src.configuration.config import Config
from src.configuration.setup_config import SetupConfig
from src.configuration.technical_config import TechnicalConfig

class JuniperLosConfig():
    _identifier = "JUNIPER_LOS_CONFIG"
    _config = None

    def __init__(self, config_file_path):
        self._config = Config(config_file_path)
        self.verify_existing_and_unique_config_names()
        
    def verify_existing_and_unique_config_names(self):
        found_configs = self._config.get_section_as_dict(self._identifier)
        unique_configs = set(found_configs)

        if len(found_configs) == 0:
            raise IOError("Failed to find any configuration paths. Please ensure at least one has been defined in {}".format(self._config.config_file_path))

        if len(found_configs) != len(unique_configs):
            raise IOError("Multiple configuration paths found with the same identifier. Please ensure each identifier is unique.")

    def get_config_names(self):
        config_items = self._config.get_section_as_dict(self._identifier)
        return [item.upper() for item in config_items]

    def get_config_path(self, config_name):
        config_path = self._config.get_string(self._identifier, config_name)
        return self.append_trailing_slash_if_not_exists(config_path)
    
    def append_trailing_slash_if_not_exists(self, file_path):
        length = len(file_path)
        if(file_path[length-1] != '\\'):
            file_path += '\\'
        return file_path
    
    def get_setup_config_path_for_config(self, config_name):
        return self.get_config_path(config_name) + "setup_config.ini"

    def get_technical_config_path_for_config(self, config_name):
        return self.get_config_path(config_name) + "technical_config.ini"