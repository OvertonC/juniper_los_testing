import configparser
from enum import Enum, auto
from datetime import datetime, date
from os import path

CONFIG_FILE_NAME = "./src/configuration/config.ini"

class Config:
    def __init__(self, config_file_path=CONFIG_FILE_NAME):
        if path.exists(config_file_path):
            self._config_file = open(config_file_path, "r")
        else:
            raise IOError("Unable to find config file. Do you have {} in your current working directory?".format(config_file_path))

        self.config_file_path = config_file_path
        self.parser = configparser.ConfigParser()
        self.parser.read(self.config_file_path)
    
    def get_section_as_dict(self, section):
        return dict(self.parser[section].items())
    
    def count_values_in_section(self, section):
        return len(self.parser[section].items())

    def get(self, section, value):
        try:
            return self.parser[section][value]
        except:
            raise KeyError("Could not find value {} in section {}".format(value, section))          

    def get_string(self, section, value):
        return str(self.get(section, value))

    def get_int(self, section, value):
        try:
            return int(self.get(section, value))
        except ValueError:
            raise ValueError("{} section has a non-integer value for {}".format(section, value))

    def get_bool(self, section, value):
        data = self.get(section, value)
        if(data == "True"):
            return True
        elif(data == "False"):
            return False
        else:
            raise ValueError("{} section has an invalid value for {}. Must be True or False".format(section, value))

    def get_date(self, section, value):
        try:
            return date.fromisoformat(self.get(section, value))
        except ValueError:
            raise ValueError("{} section has an invalid value for {}. Value should be in the format YYYY-MM-DD".format(section, value))

    def get_datetime(self, section, value):
        try:
            return datetime.fromisoformat(self.get(section, value))
        except ValueError:
            raise ValueError("{} section has an invalid value for {}. Value should be in the format YYYY-MM-DD HH:MM:SS".format(section, value)) 

    def get_bounds(self, section, value):
        import numpy as np
        print("val", np.array((self.get(section,value).split(","))).astype("float"))
        try:
            return np.array((self.get(section,value).split(","))).astype("float")
        except ValueError:
            raise ValueError("age bounds not array")        
    def __str__(self):
        str = f"Config {self.configFileName}"
        return str
