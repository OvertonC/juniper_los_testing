# Configuration README

This readme will serve as a guide to the configuration files and explain what each of the various configuration items do.

## Setup Config
The setup_config.ini file controls the data that is used in the experiments, i.e. which data is used, which age groups are selected, etc.

BASE_FILE_PATH = Where the software looks for data to use, as well as a place to store temporary data and output data.
WARD_IDENTIFIER = An identifier applied as a label to output data. This is also used to read the hospital census data.
EXTRACT_DATE_FILENAME = An identifier applied as a label to output data. This is also used to read the hospital census data.
OUTPUT_START_DATETIME = Datetime at which to start outputting data from.
LAST_ADMISSION_DATETIME = Datetime of the last admission within the dataset.
LAST_DATA_UPDATE_DATETIME = Datetime of the latest piece of information within the dataset.
GROWTH_TREND_LENGTH_DAYS = Number of days over which to estimate the growth rate trend. Try between 28 and 100.
FORECAST_START_DATE = The date of which we start predictions from.
APPROX_GROWTH_BOOL = Approximate the growth rate using the growth rate across all ages if necessary.
0_25_TO_ICU_BOOL = Do any 0-25 patients go to the ICU?
26_50_TO_ICU_BOOL = Do any 26-50 patients go to the ICU?
51_75_TO_ICU_BOOL = Do any 51-75 patients go to the ICU?
76_100_TO_ICU_BOOL = Do any 76+ patients go to the ICU?
USE_SAVED_FITTING_BOOL = Are we using a saved fitting, rather than running a new sample? This enables the forecast to be rerun without fitting the data each week.
USE_SINGLE_DISTRIBUTION_BOOL = Do we want to use combination of Burr and Weibull or just Weibull. If sample size is very small, just Weibull might be best.
GENERATE_LENGTH_OF_STAY_ESTIMATES_BOOL = Call the posterior simulator to give mean and uncertainty estimates for the observed lengths of stay

## Technical Config
The technical_config.ini file determines how model building and simulation running is carried out.

How many samples/simulation should we run? As high as possible is best, but increases computational time
NBOOT = specify number of sample to draw from MCMC posterior. The more samples used gives a better representation
NPAT = specify number of patients to simulate for posterior credibility

How many MCMC samples should be test? Again, as high as possible is best
DRAW_NUM = number of iterations to keep
TUNE_NUM = number of run in iterations to burn

How many independent chains should we run and how many cores can we use?
CHAIN_NUM = number of independent chains to run
CORE_NUM = number of cores to use, must be less than or equal to chain_num