import subprocess
import sys
import Process_data_table 
import Fit_And_Model
from src.configuration.juniper_los_config import JuniperLosConfig
from src.configuration.setup_config import SetupConfig

__version__ = '1.0.0'

class JUNIPER_LoS:
    _software_name = "Multi-state length of stay and forecasting model"
    _author_name = "Christopher Overton"
    _author_email = "christopher.overton@manchester.ac.uk"
    _author_role1 = "Data Scientist, Clinical Data Science Unit, Manchester University NHS Foundation Trust"
    _author_role2 = "Research Associate, Department of Mathematics, University of Manchester"

    def __init__(self, config_path):
        self.config = JuniperLosConfig(config_path)

    def display_software_info(self):
        print("Welcome to the " + self._software_name)
        print("Version: " + __version__)
        print("Author contact details: ")
        print(self._author_name)
        print(self._author_email)
        print(self._author_role1)
        print(self._author_role2 + "\n")

    def run_all_scripts(self):
        self.display_software_info()
        self.check_Rscript_is_installed()
        self.check_python_packages_are_installed()

        run_configurations = self.config.get_config_names()
        print("{} run configuration(s) found".format(len(run_configurations)))
        for run_configuration in run_configurations:
            print("Now running {} Juniper LoS configuration\n".format(run_configuration))
            setup_config_path = self.config.get_setup_config_path_for_config(run_configuration)
            technical_config_path = self.config.get_technical_config_path_for_config(run_configuration)
            setup_data = SetupConfig(setup_config_path)
            preset_scenario = setup_data.use_predefined_admissions()
            self.run_process_data_table(setup_config_path)
            if preset_scenario == False:
                self.run_fit_admissions(setup_config_path)
            self.run_fit_and_model(setup_config_path, technical_config_path)
        
    def run_process_data_table(self, setup_config_path):
        print("Starting to run Process_data_table\n")
        Process_data_table.run(setup_config_path)
        print("Finished Process_data_table\n")

    def run_fit_admissions(self, setup_config_path):
        print("Starting to run Fit_Admissions.R\n")
        subprocess.run(["Rscript", "Fit_Admissions.R", setup_config_path])
        print("Finished Fit_Admissions.R\n")

    def run_fit_and_model(self, setup_config_path, technical_config_path):
        print("Starting to run Fit_And_Model\n")
        Fit_And_Model.run(setup_config_path, technical_config_path)
        print("Finished Fit_And_Model\n")

    # The error message that gets returned when Rscript doesn't exist on the path is a rather generic
    # "The system cannot find the file specified". The trouble is that it's not possible to know whether
    # it's Rscript that isn't there or the .R file that we are trying to run. This function therefore
    # checks for the existence of Rscript
    def check_Rscript_is_installed(self):
        try:
            # This command is to check for Rscript. We don't want the user to see the output so suppress it
            subprocess.run(["Rscript", "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except FileNotFoundError:
            print("Unable to run Rscript. You need to have Rscript installed and on your path in order for the scripts to run.")
            print("Please check that you have R installed and that the bin directory for R is on your path")
            sys.exit()

    def check_python_packages_are_installed(self):
        print("Checking that all necessary python packages are installed...")
        reqs = subprocess.check_output([sys.executable, "-m", "pip", "list"])
        installed_packages = []
        for r in reqs.split():
            installed_packages.append(r.decode().split('==')[0])
        required_packages = ["numpy", "scipy", "matplotlib", "pandas", "tqdm", "xarray", "networkx", "seaborn", "pymc3"]
        if all(a in installed_packages for a in required_packages):
            print("All necessary python packages installed")
            return
        print("You don't seem to have all necessary python packages installed. Please ensure that the following are installed: ")
        print(*required_packages, sep="\n")
        sys.exit()


def main():
    los = JUNIPER_LoS("src\\configuration\\juniper_los_config.ini")
    los.run_all_scripts()

if __name__ == "__main__":
    main()