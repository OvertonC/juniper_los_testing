# Setting up your environment
1. Follow the instructions in README - Installation Instructions.pdf.
2. To get a fully functional python environment in Anaconda you can import the environment.yml file.

# Running the scripts
To run the scripts you simply need to run the JUNIPER_LoS.py file. 
This can be done either from command line or from within an IDE e.g. Visual Studio Code.
Make sure that you have the correct conda environment enabled when you run the script.
Depending on your machine the scripts will probably take 15-60 minutes to run to completion.

# Running the automated tests
Automated tests have been implemented using pytest.
To run the scripts run pytest from the command line (or Terminal in VSCode). This should automatically detect and run all tests.
You can optionally run pytest -v to get a more verbose output whilst the scripts are running.
Note that you will an empty conftest.py at some points in the directory structure. This helps pytest find some of the files when it is running.
Note that due to the item mentioned in "Known issues" below, three of the unit tests currently fail. When addressing the issue, making these tests pass should provide confidence that the fix has worked.
You can specify that the tests are ran on multiple threads, theoretically speeding up the execution time. This can be done with the following command `pytest -n <NUMBER_OF_THREADS>`. (Note: The execution speed increase from this is determined by the processing power of your machine. There are cases in which more threads could slow down the execution process. Bear this in mind when using this feature.)

# Known issues
There is one known issues with the current model:
1. If an input dataset has zero deaths then the model is unable to process it and will show an error message and then stop. This will be fixed in a future version of the software. However, it isn't expected to cause an issue currently as all trusts are experiencing some deaths and therefore the problem won't occur. 